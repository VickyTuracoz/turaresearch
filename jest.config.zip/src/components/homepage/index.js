import React from "react";
import { Helmet } from "react-helmet";
import { connect } from "react-redux";
import Slider from "react-slick";
import "slick-carousel/slick/slick-theme.css";
import "slick-carousel/slick/slick.css";
import PAGE_TITLES from "../../Utils/title";
import carousel1 from "../../assets/image/banner_turahealthverse.jpg";
import carousel2 from "../../assets/image/banner_turahealthverse1.jpg";
import carousel3 from "../../assets/image/banner_turahealthverse2.jpg";
import carousel4 from "../../assets/image/banner_turaverse.jpg";

const HomePage = () => {
  const carouselData = [
    {
      imageSrc: carousel3,
    },
    {
      imageSrc: carousel2,
    },
    {
      imageSrc: carousel1,
    },
    {
      imageSrc: carousel4,
    },
  ];

  let settings = {
    dots: false,
    infinite: true,
    speed: 200,
    autoplay: true,
    autoplaySpeed: 5000,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
  };

  return (
    <>
      <Helmet>
        <title>{PAGE_TITLES.home}</title>
      </Helmet>
      <div>
        <div className="relative">
          <div className="relative z-10">
            <Slider {...settings} className="slider">
              {carouselData?.map((item, index) => (
                <div
                  className=" border-0 relative active:border-0 "
                  key={index}
                >
                  <div>
                    <div classNamr="border-0 relative z-0">
                      <img
                        src={item?.imageSrc}
                        alt="carousel"
                        class="image-carousal relative z-0"
                      />
                      <div className="flex flex-col absolute z-10 justify-center items-center top-1/4 left-1/4 p-6 md:p-10 xl:p-20">
                        <div class="xl:text-7xl text-white md:text-4xl drop-shadow-2xl text-2xl font-semibold text-shadow">
                          HEALTHCARE FOR ALL
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </Slider>
          </div>
          <div className=" bg-yellow-50 -mt-2 ">
            <div className="flex container mx-auto flex-row text-purple-700 justify-between items-center h-24">
              <div className="flex gap-2 items-center">
                <span className="text-3xl  font-semibold">40+</span> Year Of
                Expertise
              </div>
              <div className="flex gap-2 items-center">
                <span className="text-3xl  font-semibold">120M</span> People
                Reached Annually
              </div>
              <div className="flex gap-2 items-center">
                <span className="text-3xl  font-semibold">100+</span> Medical
                Experts
              </div>
            </div>
          </div>
          <div className=" container my-4 mx-auto flex flex-row">
            <div className="w-3/4">
              <div className="text-3xl font-semibold">WHAT WE DO</div>
              <div className="my-8 pr-4">
                Smile Foundation’s comprehensive and community-centric health
                programme takes primary healthcare services to the doorsteps of
                underserved communities in both rural and urban India. Following
                a two pronged approach, the programme provides curative as well
                as preventive services, addressing the gaps in availability,
                accessibility and affordability of healthcare.
              </div>
              <div className="text-3xl mt-8 font-semibold">
                OUR FOCUS, VALUE AND MISSION
              </div>
              <div className="my-8 pr-4">
                Smile Foundation’s comprehensive and community-centric health
                programme takes primary healthcare services to the doorsteps of
                underserved communities in both rural and urban India. Following
                a two pronged approach, the programme provides curative as well
                as preventive services, addressing the gaps in availability,
                accessibility and affordability of healthcare.
              </div>
            </div>
            <div className="w-1/4">
              <div className="border p-4 border-slate-800 rounded-md">
                <div className="text-xl font-medium">
                  LATEST HEALTHCARE NEWS
                </div>
                <ol className="list-disc mt-8">
                  <li>
                    Challenges in last mile delivery of healthcare in rural
                    areas
                  </li>
                  <li>
                    Making Healthcare System in India a Major Agenda for G20
                    2023
                  </li>
                  <li>Turning 100– Indian Healthcare System in 25 Years</li>
                </ol>
              </div>
              <div className="border p-4 mt-8 border-slate-800 rounded-md">
                <div className="text-xl font-medium">
                  UPCOMING WEBINARS AND EVENTS
                </div>
                <ol className="list-disc mt-8">
                  <li>
                    Challenges in last mile delivery of healthcare in rural
                    areas
                  </li>
                  <li>
                    Making Healthcare System in India a Major Agenda for G20
                    2023
                  </li>
                  <li>Turning 100– Indian Healthcare System in 25 Years</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state) => ({});

const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(HomePage);
