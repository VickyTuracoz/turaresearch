import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <>
      <div className="w-full p-0 sticky top-0 h-16 bg-white z-50">
        <div className="container mx-auto">
          <div className="py-0 flex justify-center md:justify-between items-start">
            <Link
              className="py-2 font-semibold text-3xl drop-shadow-2xl"
              to="/"
            >
              Logo
            </Link>
            <div className="mt-4">
              <ul className="flex list-unstyled text-purple-700 font-medium m-0 gap-4">
                <li className="font-weight cursor-pointer">
                  OUR FOCUS, VALUE AND MISSION
                </li>
                <li className="font-weight cursor-pointer">STORIES</li>
                <li className="font-weight cursor-pointer relative group">
                  COMBAT HEALTH
                </li>
                <li className="font-weight cursor-pointer">PUBLICATIONS</li>
                <li className="font-weight cursor-pointer">
                  UPCOMING ACTIVITIES AND EVENTS
                </li>
                <li className=" font-weight request cursor-pointer">
                  SOCIAL MEDIA HANDLES
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;
