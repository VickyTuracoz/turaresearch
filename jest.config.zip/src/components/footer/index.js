import React from "react";
import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaTwitter,
} from "react-icons/fa";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <div className="container mx-auto bg-white">
      <div className="flex flex-col md:flex-row justify-start  md:justify-between items-start md:items-center pt-12 mt-4">
        <div className="flex flex-col footer-text py-4">
          <div className="flex gap-5">
            <span>
              <Link to="https://www.facebook.com/turacozhealthcaresolutions/">
                <FaFacebookF size={18} />
              </Link>
            </span>
            <span>
              <Link to="https://www.instagram.com/turacoz/">
                <FaInstagram size={18} />
              </Link>
            </span>
            <span>
              <Link to="https://www.linkedin.com/company/turacoz-healthcare-solutions/">
                <FaLinkedinIn size={18} />
              </Link>
            </span>
            <span>
              <Link to="https://twitter.com/i/flow/login?redirect_after_login=%2Fturacoz">
                <FaTwitter size={18} />
              </Link>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
