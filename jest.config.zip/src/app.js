import React, { Suspense, lazy } from "react";
import ReactDOM from "react-dom/client";
import {
  createBrowserRouter,
  RouterProvider,
  Outlet,
  Navigate,
} from "react-router-dom";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import Header from "./components/header/index";
import Footer from "./components/Footer";
import Loading from "./components/Loading";
import Error from "./components/Error";
import { persistor, store } from "./redux/store";
const HomePage = lazy(() => import("./components/homepage/index"));

const App = () => {
  return (
    <Provider store={store}>
      <PersistGate persistor={persistor}>
        <Header />
        <Outlet />
        <Footer />
      </PersistGate>
    </Provider>
  );
};

const appRoutes = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <Error />,
    children: [
      {
        path: "/",
        element: (
          <Suspense fallback={<Loading />}>
            <HomePage />
          </Suspense>
        ),
      },
    ],
  },
]);
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<RouterProvider router={appRoutes} />);
