const PAGE_TITLES = {
  home: "Turacoz Healthcare Solutions",
};

export default PAGE_TITLES;
